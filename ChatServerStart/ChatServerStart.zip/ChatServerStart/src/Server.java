import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Server {

  public static final int SERVER_PORT = 9001;

  private static ServerSocket socket;
  
  // Add all output streams that connect to this list
  private static List<ObjectOutputStream> clients = Collections
      .synchronizedList(new ArrayList<>());

  public static void main(String[] args) throws IOException {
    socket = new ServerSocket(SERVER_PORT);
    System.out.println("Server started on port " + SERVER_PORT);

    while (true) {
      // TODO 1: Accept a connection from the ServerSocket (replace null)
      Socket socket = null;

      ObjectInputStream is = new ObjectInputStream(socket.getInputStream());
      ObjectOutputStream os = new ObjectOutputStream(socket.getOutputStream());

      // TODO 2: Add the output stream to our list of clients
      // so we can write to all client later

      // TODO 3: Start a new ClientHandler thread for this client by 
      // constructing a new ClientHandler (which extends Thread) 
      // and sending it the start method in class Thread which sends
      // a message back down to the run method in the class below.

      // These printlns are not really needed
      System.out.println("Accepted a new connection from " + socket.getInetAddress());
    }
  }
}

class ClientHandler extends Thread {

  private ObjectInputStream input;
  private List<ObjectOutputStream> clients;

  public ClientHandler(ObjectInputStream input, List<ObjectOutputStream> clients) {
    this.input = input;
    this.clients = clients;
  }

  @Override
  public void run() {
    while (true) {

      String message = null;

      // TODO 4: Read a String from the client. 
      // Note: This will remove the compile time errors 
      // below because readObject may throw an IOException.
      // Need try/catch 

      // Call a method to send this message to all ObjectOutputStreams
      this.writeStringToClients(message);
    }
  }

  private void writeStringToClients(String message) {
    synchronized (clients) {

      // TODO 5: Use an enhanced for loop to Send a string to all clients 
      // the client list by iterating over all ObjectOutputStreams in clients

      // TODO 6: After writeObject, do NOT forget reset(). This would be 
      // a silent error that results in the server not working.

      // TODO 7: In the catch block, remove the ObjectOutputStream
      // from the list (ArrayList has remove(E element))

    }
  }

}